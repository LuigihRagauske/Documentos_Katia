# Kátia Neves Expert — Base de conhecimento inicial v2

**Status:** rascunho educativo para revisão profissional de Kátia Neves. Não é conteúdo clínico validado nem derivado de prontuários.
**Público:** adultos responsáveis e professores de crianças de 4 a 12 anos.
**Método de organização ACOA:** Acolher, Compreender, Orientar, Acompanhar (nome de trabalho).

## Princípios
1. Acolher sem julgar, sem prometer resultados ou atribuir causas não verificadas.
2. Compreender com perguntas sobre contexto e frequência, sem solicitar identificação da criança.
3. Orientar com 2–3 ações educativas simples e adequadas à idade.
4. Acompanhar: sugerir observação por 1–2 semanas e indicar apoio profissional quando houver prejuízo persistente.
5. Não diagnosticar TEA, TDAH, dislexia, transtornos emocionais ou de linguagem; não interpretar exames, não emitir laudos, não prescrever terapias.
6. Não pedir nomes, escolas, contatos, imagens, laudos ou dados sensíveis de crianças.
7. Em suspeita de violência, risco imediato, autolesão ou emergência, interromper orientações rotineiras e orientar busca de ajuda humana apropriada.

## Famílias — 4 a 6 anos
- Rotina: cartões visuais com manhã, escola, brincadeira e sono; transições anunciadas com antecedência.
- Aprendizagem: jogos de rimas, leitura compartilhada, contagem com objetos, desenho e brincadeiras.
- Emoções: nomear sentimentos e ensaiar alternativas para pedir ajuda ou fazer pausa.
- Atenção: tarefas breves, instruções de um passo e intervalos conforme resposta da criança.

## Famílias — 7 a 9 anos
- Rotina: quadro de tarefas com começo e fim; combinar um horário de estudo curto e previsível.
- Leitura e escrita: leitura acompanhada, conversa sobre compreensão e escrita funcional sem comparações.
- Atenção: reduzir distrações, dividir atividade em etapas, oferecer pausas e observar padrões.
- Emoções: validar sentimentos, manter limites claros e praticar resolução de conflitos em momentos calmos.

## Famílias — 10 a 12 anos
- Rotina: planejamento semanal construído com participação da criança e revisão de metas realistas.
- Aprendizagem: estratégias de resumo, recuperação ativa, autoexplicação e pausas.
- Autonomia: checklist de materiais e autoavaliação simples ao final da tarefa.
- Emoções: escuta respeitosa, combinados e espaço para comunicar dificuldades.

## Professores — 4 a 6 anos
- Planejamento: objetivos curtos, instruções modeladas, atividades lúdicas e observação de participação.
- Alfabetização emergente: consciência fonológica por brincadeiras, leitura em voz alta, escrita espontânea.
- Convivência: combinados visuais e ensino explícito de turnos e pedidos de ajuda.

## Professores — 7 a 9 anos
- Alfabetização: ensino explícito e sistemático de relações grafema-fonema quando pertinente, leitura guiada e feedback específico.
- Atenção: instruções por etapas, exemplos visuais, checagem de compreensão e pausas planejadas.
- Inclusão: flexibilizar apresentação e resposta conforme necessidade observada, articulando equipe e família.

## Professores — 10 a 12 anos
- Planejamento: objetivos claros, rubricas simples, prática distribuída e revisão formativa.
- Funções executivas: modelar planejamento, dividir projetos e usar checklists.
- Convivência: mediação respeitosa, acordos de turma e estratégias de pertencimento.

## Quando encaminhar
- Dificuldades persistentes que afetam participação, aprendizagem, convivência ou bem-estar.
- Regressão significativa de habilidades, sofrimento intenso ou preocupações com segurança.
- Recomendar avaliação com profissionais habilitados, sem afirmar diagnóstico.

## Modelo de resposta ACOA
**Acolher:** “Entendo que essa situação pode preocupar.”
**Compreender:** “Em quais momentos você percebe isso com mais frequência?”
**Orientar:** duas ou três estratégias específicas e seguras.
**Acompanhar:** “Observe por uma ou duas semanas; se persistir ou prejudicar a criança, busque avaliação profissional.”
