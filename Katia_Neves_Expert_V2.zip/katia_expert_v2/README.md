# Kátia Neves Expert — Protótipo V2

## O que funciona agora
- Página web responsiva para celular e computador.
- Escolha entre **Famílias** e **Professores** e três faixas etárias (4–6, 7–9, 10–12).
- Respostas educativas pré-escritas por público, faixa e tema; conversa local na aba do navegador.
- Botões de temas, campo de pergunta, alerta de privacidade, aviso de limites e opção de limpar a conversa.
- Arquivo `base_conhecimento.md` com conteúdo inicial para revisão profissional.

## O que NÃO está pronto
- **Não há conexão com IA generativa**: respostas são selecionadas por regras e palavras-chave.
- Não há login, pagamentos, banco de dados, agendamentos, histórico persistente nem área de assinantes.
- Não há política de privacidade completa, termo de uso ou revisão jurídica; não usar como atendimento profissional individualizado.

## Testar
1. Descompacte o ZIP.
2. Abra `index.html` no navegador do computador; no celular, publique os arquivos num serviço de hospedagem estática e teste o link.
3. Selecione o público, faixa etária e um tema; faça perguntas gerais sem dados pessoais de crianças.
4. Revise `base_conhecimento.md` antes de qualquer divulgação pública.

## Publicar um link de demonstração
Envie a pasta com `index.html` a um serviço de hospedagem estática como Netlify Drop. A publicação cria um link público, mas **não adiciona IA generativa**. Não envie a chave de API no HTML/JavaScript.

## Próxima versão com IA real
- Criar backend serverless que recebe público, faixa etária e pergunta, aplica limites de segurança e chama API de IA com chave guardada em variável de ambiente.
- Adicionar limitação de uso, proteção contra abuso, política de privacidade e minimização de dados.
- Fazer testes de segurança e qualidade com casos fictícios e revisão de Kátia Neves.
- Só então avaliar cobrança e acesso restrito.

## Orçamento de referência (teto R$ 500)
- Hospedagem e domínio: até R$ 100 no piloto (pode começar grátis).
- Créditos API: até R$ 100, após backend e limites.
- Identidade visual: até R$ 50.
- Divulgação controlada: até R$ 150.
- Reserva: R$ 100.

O protótipo atual custa R$ 0 para executar localmente.
